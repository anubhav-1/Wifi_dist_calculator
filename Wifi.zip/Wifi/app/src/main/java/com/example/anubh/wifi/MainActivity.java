package com.example.anubh.wifi;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import static com.example.anubh.wifi.R.id.button1;
import static java.lang.StrictMath.abs;
import static java.lang.StrictMath.sqrt;

public class MainActivity extends AppCompatActivity {


    private Button button;
    TextView textview;


    WifiManager wifiManager;
    WifiInfo connection;

    String display;
    int strength;
    Boolean loop = Boolean.TRUE;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = (Button) findViewById(button1);
        textview = (TextView) findViewById(R.id.text1);

        button.setOnClickListener(new View.OnClickListener(){


            public void onClick(View arg0){

                            wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
                            connection = wifiManager.getConnectionInfo();
                            strength = abs(connection.getRssi());
                if (strength <= 30) {
                    display = "Approximate Distance: " + 0;
                }
                else {
                    display = "Approximate Distance: " + sqrt(strength-30)/2;
                }

                            textview.setText(display);





            }
        });







    }
}
